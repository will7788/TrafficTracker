import java.util.ArrayList;

public class CapacityMonitor {

	public static void main(String[] args) {
		int storeCount = 0;
		/* if sensor trips, update store count based on where from.
		   this code may be moved to a new logic bean*/
		
		// generate customers (if only it were so easy)
		int min = 0;
		int max = 30;
		int numCustomers = (int)(Math.random() * (max - min + 1) + min); // generates within min-inclusive and max-exclusive values
		ArrayList<Customer> queue = new ArrayList<Customer>();
		
		for (int i = 0; i<numCustomers; ++i) {
			queue.add(new Customer(i));
		}
		
		System.out.println(numCustomers+" Customers created.");
		
		// trip the sensor as customers "enter"
		Sensor entranceSensor = new Sensor();
		Sensor exitSensor  = new Sensor();
		
		// random number less than total in queue enter
		int numCustomersEnter = (int)(Math.random() * (numCustomers - min + 1) + min);
		for (int i=0; i<numCustomersEnter; ++i){
			entranceSensor.trip();
			storeCount++;
			System.out.println("Entrance Sensor tripped");
			entranceSensor.reset();
		}
		System.out.println(numCustomersEnter+" customers have entered. Store count is "+storeCount);
		
		// random number less than total in store leave
		int numCustomersLeave = (int)(Math.random() * (numCustomersEnter - min + 1) + min);
		for (int i = 0; i<numCustomersLeave; ++i) {
			exitSensor.trip();
			storeCount--;
			System.out.println("Exit sensor tripped");
			exitSensor.reset();
		}
		System.out.println(numCustomersLeave+" customers have left. Store count is "+storeCount);

	}

}
