
public class Customer {
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public Customer(int id) {
		this.id = id;
	}
}
